// Sample data for timeline
const timelineData = [
    { date: "1877", description: "Born on November 9 in Sialkot, Pakistan." },
    { date: "1905", description: "Published his first collection of poetry, 'Bang-e-Dra'." },
    { date: "1930", description: "Delivered the famous Allahabad Address, outlining his vision for a separate Muslim state." },
    { date: "1938", description: "Passed away on April 21 in Lahore, Pakistan." }
  ];
  
  // Function to populate timeline
  function populateTimeline() {
    const timelineList = document.getElementById("timeline-list");
    timelineData.forEach(item => {
      const li = document.createElement("li");
      li.innerHTML = `<strong>${item.date}:</strong> ${item.description}`;
      timelineList.appendChild(li);
    });
  }
  
  // Image slideshow functionality
  let currentSlide = 0;
  const slides = document.querySelectorAll("#slideshow img");
  
  function nextSlide() {
    slides[currentSlide].classList.remove("active");
    currentSlide = (currentSlide + 1) % slides.length;
    slides[currentSlide].classList.add("active");
  }
  
  // Populate timeline and set up slideshow on page load
  document.addEventListener("DOMContentLoaded", () => {
    populateTimeline();
  
    // Set up slideshow
    setInterval(nextSlide, 3000); // Change slide every 3 seconds (adjust as needed)
  });
  